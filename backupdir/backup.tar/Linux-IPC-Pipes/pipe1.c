// C Program that illustrate communication between two process using unnamed pipes
